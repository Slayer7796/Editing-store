 var Tutorialdata = [
   {
     id: "page3-increase-video-quality",
     name: "Increase video quality in Alight motion ",
     date: 'date :21-May-2022',
     image: "/tutorial image/increase quality cc.jpg",
     video: "https://www.youtube.com/embed/zL35zpzyaS0",
     app: "Alight motion n\ kinemaster",
     tutorial: `Certainly! Here's a step-by-step guide on how to increase the video quality in Alight Motion :

To enhance the video quality in Alight Motion, follow these steps:

1. Add a rectangle shape layer to your project and set it to full-screen size for comprehensive viewing.

2. Apply the "Copy Background" effect to the layer. This effect duplicates the background, which can be useful for further enhancements.

3. Add the "Gaussian Blur" effect to the layer and increase the "Max Blur Strength" to achieve a desired blur effect. Gaussian blur can help smooth out imperfections and create a more polished look.

4. Apply the "Exposure" and "Gamma" effects to the layer. Decrease the exposure by -1.81 to darken the image slightly, and increase the gamma by 1.41 to enhance the overall contrast.

5. Adjust the blending mode of the layer. Choose the "Difference" option from the blending mode menu and select the "Subtract" option within the layer. This blending mode can create interesting visual effects by comparing the layer with the underlying elements.

6. Add a white rectangle shape layer to your project.

7. Modify the blending mode of the white rectangle layer. Choose the "Contrast" option from the blending mode menu and select the "Overlay" option. Adjust the opacity of the layer as desired to control the intensity of the effect.

By following these steps, you can effectively increase the video quality in Alight Motion. Remember to experiment with different settings and adjustments to achieve the desired outcome.
      
      `
  },
   {
     id: "page3-twixtor-clips-editing",
     date: 'date:10-june-2024',
     name: "Smooth twixtor clips editing tutorial",
     image: "/tutorial image/smooth twixtor.jpg",
     video: "https://www.youtube.com/embed/d4_NJWsQNrA",
     app: ["Avu editor", "kinemaster"],
     tutorial: `
    1. Install Kinemaster and Avu editor:
    Download and install the Kinemaster and Avu editor app from the provided link or the Google Play Store (for Android) or the App Store (for iOS). Make sure you have the latest version of the app installed or the version provided.
    
    2. Import your video clip: Open Avu editor and click on the "Smooth Slow Motion" feature. Choose the clip you want to create Twixtor for. After the processing is complete, select the "Super Slow" option, 120fps, and high quality. Click on the "Smooth Slow Motion" feature and wait a few minutes for the processing to complete. Save the Twixtor file.
    
    3. Import your video clip: Open Kinemaster and create a new project. Tap on the "+" icon to import your video clip into the project. You can import videos from your device's gallery or capture new footage using the app's camera feature.
    
    4. Add the Twixtor effect: Once your video clip is imported, tap on the layer where the video clip is located to select it. Then, tap on the "Layer Tools" icon (represented by three stacked squares) at the top-right corner of the screen. From the list of options, choose "Speed Control."
    
    5. Adjust the speed: In the Speed Control menu, you'll find options to adjust the playback speed of the video. Drag the speed slider towards the left to slow down the video. You can also manually enter a specific speed value. Experiment with different speed settings until you achieve the desired slow-motion effect.
    
    6. Enable frame interpolation: To enhance the smoothness of the slow-motion effect, tap on the "Advanced" tab in the Speed Control menu. Toggle on the "Frame Interpolation" option. This feature is similar to what Twixtor offers, helping to create smoother slow-motion footage.
    
    7. Preview and fine-tune: Play the video in the Kinemaster preview window to see the Twixtor effect in action. If needed, go back to the Speed Control menu and make further adjustments to the speed or frame interpolation settings until you're satisfied with the result.
    
    8. Apply additional edits: After applying the Twixtor effect, you can continue editing your video in Kinemaster. Add transitions, text overlays, music, or any other desired effects to enhance your video.
    
    9. Export your video: Once you've finished editing, tap on the "Export" button in Kinemaster to save your video. Choose your desired export settings, such as resolution and file format, and wait for the app to render and export your final video.
    
    That's it! You've successfully used the Twixtor effect in Kinemaster to create a slow-motion video clip. Remember to explore and experiment with other features and effects available in the app to further enhance your videos.
    `,
  },
   {
     id: "page3-how-to-put-overlay-behind-charector-in-alight-motion-amv-editing-tutorial",
     date: 'date:19-june-2022',
     name: "put overlay behind charector in Alight motion",
     image: "/tutorial image/How to put overlay behind charector .jpg",
     video: "https://www.youtube.com/embed/n5Xyhj44vj8",
     app: ["Avu editor", "kinemaster"],
     tutorial: `
    Certainly! Below are the three methods for putting an overlay behind a character in Alight Motion, explained sequentially, along with additional information for each method:

Method 1: Using Vector Drawing and Blending Modes</h4>

Step 1: Open Alight Motion and import your video clips for your AMV edit, including the one with the character you want to overlay.

Step 2: Click on the "Vector Drawing" feature in Alight Motion. This feature allows you to draw shapes and create custom elements.

Step 3: Apply the "Copy Background" effect in the Vector Drawing feature. This effect duplicates your video's background, which will be used for the overlay later.

Step 4: Draw a shape outside the borders of your character, creating a placeholder for the overlay behind the character.

Step 5: Import the overlay you want to use and place it on the timeline in a layer above the character clip.

Step 6: Set the duration of the overlay clip to match the duration of the character clip, ensuring they stay synchronized.

Step 7: Select both the Vector Drawing layer with the shape and the overlay layer. In Alight Motion, you'll see a "Group" option in the top toolbar. Tap on "Select 3D Group" to group these two layers together.

Step 8: After creating the group, click on the "Blending Mode" option and select "Light Color Dodge." This blending mode will make the overlay blend nicely behind the character, creating a more seamless effect.

Method 2: Using Unscreen for Background Removal

Step 1: Visit the website "unscreen.com" to remove the background from your video clips. This website offers a tool that can automatically remove the background from videos.

Step 2: Upload your video clips to the Unscreen website to begin the background removal process.

Step 3: On the Unscreen website, locate the "Color Change" option and select the green color. This step is important because Alight Motion often uses green screen effects, and choosing a green background will make it easier to remove it later.

Step 4: Once the background is removed and the video is ready, download the clip from the Unscreen website.

Step 5: If the downloaded clip is in GIF format, you can use a GIF to video converter application from the Play Store to convert it to a video format that Alight Motion supports.

Step 6: Now, open Alight Motion and start a new project. Add your original clip to the timeline as the base layer.

Step 7: Next, add the clip that you processed through Unscreen, which now has the background removed, to the timeline as a layer above the original clip.

Step 8: Select the clip with the removed background and apply the "Chroma Key" effect. This effect will remove the green background from the clip, leaving only the character visible.

Step 9: Finally, add the overlay clip that you want to place behind the character. Position it on the timeline in the second layer and adjust the timing as needed.

Step 10: To make the overlay blend seamlessly behind the character, select the overlay clip, go to the "Blending Mode" option, and choose "Lighting."

Method 3: Using Chroma Key and Color Removal

Step 1: Open Alight Motion and add the video clips you want to use, including the one with the character you want to place the overlay behind.

Step 2: Apply the "Chroma Key" effect to the video clip with the character. This effect will help remove the background from this clip.

Step 3: In the Chroma Key settings, you'll find a "Color Options" button. Click on it to access more features.

Step 4: Among the available features, click on the first one, which allows you to use a color picker tool to select the color you want to remove from the background.

Step 5: Move the color picker tool over the background you want to remove and click to select the color. The tool will help identify the color to be removed.

Step 6: After selecting the color, you may need to fine-tune the removal process. You can decrease the "Threshold" setting to ensure a more accurate removal of the background.

Step 7: Adjust the settings until you are satisfied with the background removal. Repeat the steps if you have more areas in the clip's background that need to be removed.

Step 8: Once you have successfully removed the background from your clip, it will now appear as if the character is isolated from the original background.

Step 9: Now, you can add the overlay clip that you want to place behind the character. Position it on the timeline in a layer below the character clip.

Step 10: Play the video to preview the result and make any additional adjustments if necessary.

Additional Information and Why to Use Each Method:

Method 1: Using Vector Drawing and Blending Modes

- This method is a creative way to add overlays behind characters, as it allows you to draw custom shapes to fit the scene precisely.
- Grouping the Vector Drawing layer with the overlay clip makes it easier to manage and apply blending modes to achieve seamless integration.
- The "Light Color Dodge" blending mode brightens the overlay, giving it a glowing effect that complements the character's appearance.

Method 2: Using Unscreen for Background Removal

- Unscreen is a web-based tool that can efficiently remove backgrounds from videos, saving you time and effort.
- By removing the background using Unscreen, you can easily place the character with transparency over other clips or backgrounds in Alight Motion.
- This method is especially useful if your original video doesn't have a green screen, as Unscreen allows you to remove the background without the need for physical green screens during filming.

Method 3: Using Chroma Key and Color Removal

- The Chroma Key effect in Alight Motion is a quick and effective way to remove backgrounds, especially if you have shot your video using a green screen.
- Fine-tuning the background removal using the color picker tool and threshold settings ensures accurate removal and minimal artifacts in the final result.
- This method is ideal when you have a specific background color to remove, making it versatile for various situations.

In conclusion, each method offers its own advantages for adding overlays behind characters in Alight Motion. Method 1 allows for creative customization using vector drawing and blending modes, while Method 2 simplifies background removal with Unscreen. Method 3 is a reliable choice when dealing with green screen footage or specific background colors. Depending on your project's requirements and available resources, you can choose the most suitable method to achieve your desired AMV edit with captivating overlays behind characters.
    `,
  },
   {
     id: "alight-motion-basic-transtion-tutorial",
     name: "Alight motion basic transition tutorial",
     date: 'date :10-June-2022',
     image: "/tutorial image/Basic transition in amv edit .jpg",
     video: "https://www.youtube.com/embed/MfW0kC9WQYg",
     app: "Alight motion",
     tutorial: `Alight Motion is a popular video editing app that allows users to create AMVs (Anime Music Videos) and other types of creative video content. When it comes to basic transitions for AMV editing, there are several options you can use to make your videos more visually appealing. Here are some common basic transitions you can try in Alight Motion:

1. **Cut**: The simplest transition is a straight cut from one clip to another. This creates a seamless switch between two scenes without any effects or transitions.

2. **Fade In/Fade Out**: To create a smooth transition between clips, you can use the fade-in and fade-out effects. The fade-in effect gradually brings the next clip into view, while the fade-out effect slowly makes the current clip disappear.

3. **Cross Dissolve**: This transition blends two clips together, creating a smooth crossfade between them. It's a classic transition used in video editing.

4. **Slide**: You can slide one clip out of the frame while simultaneously sliding the next clip into view. This can be a horizontal, vertical, or diagonal movement.

5. **Push**: A push transition involves pushing one clip off the screen to reveal the next clip underneath.

6. **Wipe**: A wipe transition moves a solid line, shape, or pattern across the screen to reveal the next clip.

7. **Zoom In/Out**: Using the zoom effect, you can make the current clip zoom in until it fills the screen, or zoom out to reveal the next clip.

8. **Rotation**: A rotation transition involves rotating one clip out of the frame while rotating the next clip into view.

9. **Masking**: Masking allows you to creatively transition between two clips by revealing one clip through a shape or object.

10. **Flip**: The flip effect flips the current clip to reveal the next clip on the other side.

To apply these transitions in Alight Motion:

1. Import your video clips into the app and arrange them on the timeline in the order you want them to appear.

2. Tap on the transition point between two clips on the timeline.

3. Choose the desired transition from the available effects or options.

4. Adjust the duration and other settings of the transition as needed.

Remember, while transitions can enhance your AMV, it's essential to use them judiciously and match them with the mood and tempo of the music and the overall style of your video. Overusing transitions can make your AMV look cluttered and distracting. Experiment with different transitions to find what works best for your project.`
  },
   {
     id: "page3-smooth-twixtor-,editing-tutoril",
     name: "Smooth Twixtor editing tutoril",
     date: 'date :12-January-2023',
     image: "/tutorial image/smooth twixtor p2.jpg",
     video: "https://www.youtube.com/embed/ET0YoXNtbjc",
     app: "Capcut, avu editor",
     tutorial: ``
  },
  ]

 export { Tutorialdata }