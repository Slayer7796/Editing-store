import { Twixtordata } from './Twixtor.js';
import { Preset } from './productdata.js';
import { Tutorialdata } from './tutorial.js';

const allproductdata = [];
Twixtordata.forEach(mydata => {
  allproductdata.push(mydata);
});
Preset.forEach(mydata => {
  allproductdata.push(mydata);
});
Tutorialdata.forEach(mydata => {
  allproductdata.push(mydata);
});

const productcontainer = document.querySelector(".Container");
const detailscontainer = document.querySelector(".DetailsContainer");
const searchbtn = document.querySelector(".sbottun");
const searchbar = document.querySelector('.search-bar')
function searchTwixtorData(query) {
  const filteredData = allproductdata.filter(product =>
    product.name.toLowerCase().includes(query.toLowerCase())
  );

  productcontainer.innerHTML = ''; // Clear the product container to display the filtered results

  if (filteredData.length > 0) {
    filteredData.forEach(product => {
      let productDiv = document.createElement('div');
      let productImage = document.createElement('img');
      let datecontainer = document.createElement('p');
      let productName = document.createElement('h1');
      productDiv.classList.add("data");

      productName.textContent = product.name;
      datecontainer.textContent = product.date;
      productImage.src = product.image;
      productDiv.appendChild(productImage);
      productDiv.appendChild(productName);
      productDiv.appendChild(datecontainer);

      productcontainer.appendChild(productDiv);

      productDiv.addEventListener('click', function() {
        var path = window.location;
        console.log(path);

        if (product.id.startsWith("page1")) {
          const productId = product.id;
          navigateToPreset(`/preset/${productId}`);
        } else if (product.id.startsWith("page2")) {
          const productId = product.id;
          navigateToTwixtor(`/twixtor/${productId}`);
        }
        else if (product.id.startsWith("page3")) {
          const productId = product.id;
          navigateTotutorial  (`/tutorial/${productId}`);
        }
      });
    });
  } else {
    productcontainer.innerHTML = '<p>No results found.</p>';
  }
}

// Event listener for search button click
searchbar.addEventListener('keyup', function() {
  const searchTerm = searchbar.value;
  searchTwixtorData(searchTerm);
});

function convertToDate(dateString) {
  const dateParts = dateString.split(':');
  const date = dateParts[1].trim().split('-');
  return new Date(date[2], getMonthIndex(date[1]), date[0]);
}

// Helper function to get the month index based on its name
function getMonthIndex(month) {
  const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];
  const shortMonthNames = monthNames.map(month => month.slice(0, 3));

  const index = shortMonthNames.indexOf(month) !== -1 ?
    shortMonthNames.indexOf(month) :
    monthNames.indexOf(month);

  return index !== -1 ? index : 0;
}

allproductdata.sort((a, b) => convertToDate(b.date) - convertToDate(a.date));

allproductdata.forEach(product => {
  const productDiv = document.createElement("div");
  productDiv.classList.add("data");
  const title = document.createElement("h2");
  title.textContent = product.name;
  const date = document.createElement("p");
  date.textContent = product.date;
  const image = document.createElement("img");
  image.src = product.image;
  productDiv.appendChild(image);
  productDiv.appendChild(title);
  productDiv.appendChild(date);

  productcontainer.appendChild(productDiv);

  productDiv.addEventListener('click', function() {
    var path = window.location;
    console.log(path);

    if (product.id.startsWith("page1")) {
      const productId = product.id;
      navigateToPreset(`/preset/${productId}`);
    } else if (product.id.startsWith("page2")) {
      const productId = product.id;
      navigateToTwixtor(`/twixtor/${productId}`);
    }
    else if (product.id.startsWith("page3")) {
      const productId = product.id;
      navigateTotutorial(`/tutorial/${productId}`);
    }
  });
});

function handlePresetClick(productId) {
  const product = Preset.find(x => x.id === productId);
  if (product) {
    const html = "<h1>" + product.name + "</h1>" +
      "<img src=\"" + product.image + "\" alt=\"" + product.name + "\">" +
      "<h4>" + "Audio: " + "</h4>" + "<p>" + product.audioname + "</p>" +
      "<h4>" + "Anime: " + "</h4>" + "<p>" + product.animename + "</p>" +
      "<h4>" + "Editing App: " + "</h4>" + "<p>" + product.editingapp + "</p>" +
      "<h4>" + "Audio Link :- " + "<a href=\"" + product.audiolink + "\">" + "click here" + "</a>" + "</h4>" +
      "<h4>" + "Preset Link :- " + "<a href=\"" + product.presetlink + "\">" + "click here" + "</a>" + "</h4>" +
      "<h4>" + "Twixtor Link :- " + "<a href=\"" + product.twixtorlink + "\">" + "click here" + "</a>" + "</h4>" +
      "<h4>" + "Audio Link :- " + "<a href=\"" + product.audiolink + "\">" + "click here" + "</a>" + "</h4>" +
      "<h4>" + "Alight motion :- " + "<a href=\"" + product.applink + "\">" + "click here" + "</a>" + "</h4>" +
      "<h4>" + "Pack Details: " + "</h4>" + "<p>" + product.packdetails + "</p>" +
      "<h4>" + "Discrimination: " + "</h4>" + "<p>" + product.discrimination + "</p>";
    detailscontainer.innerHTML = html;
  }
}

// Function to handle URL change for Preset
function preseturlchange() {
  const path = window.location.pathname;

  if (path.startsWith('/preset/')) {
    const productId = path.substring('/preset/'.length);
    handlePresetClick(productId);
    productcontainer.style.display = "none";
    detailscontainer.style.display = "block";
  } else {
    detailscontainer.innerHTML = '';
    productcontainer.style.display = "grid";
    detailscontainer.style.display = "none";
  }
}

// Function to navigate to a path and handle URL change for Preset
function navigateToPreset(path) {
  window.history.pushState({}, '', path);
  preseturlchange();
}

// Event listener for popstate event
window.addEventListener('popstate', () => {
  preseturlchange();
});

function handletwixtorclick(productId) {
  const product = Twixtordata.find(x => x.id === productId);
  if (product) {
    let html = "<h1>" + product.name + "</h1>" +
      "<h4>" + "Video Link:</h4>" +
      "<iframe width=\"560\" height=\"315\" src=\"" + product.video + "\" frameborder=\"0\" allowfullscreen></iframe>" +
      "<h4>" + "Twixtor with without CC:"
      "<a href=\"" + product.clips1 + "\">" + "click here" + "</a>" + "</h4>";

    // Check if "clips2" link is available
    if (product.clips2 && product.clips2 !== "") {
      html += "<h4>" + "Twixtor With 4k cc: " + "<a href=\"" + product.clips2 + "\">" + "click here" + "</a>" + "</h4>";
    } else {
      html += "<h4>" + "Twixtor With 4k cc: Sorry, this is not available" + "</h4>";
    }

    html += "<h4>" + "Discrimination: " + "</h4>" + "<p>" + product.discrimination + "</p>";
    detailscontainer.innerHTML = html;
  }
}

// Function to handle URL change for Twixtor
function twixtorurlChange() {
  const path = window.location.pathname;

  if (path.startsWith('/twixtor/')) {
    const productId = path.substring('/twixtor/'.length);
    handletwixtorclick(productId);
    productcontainer.style.display = "none";
    detailscontainer.style.display = "block";
  } else {
    detailscontainer.innerHTML = '';
    productcontainer.style.display = "grid";
    detailscontainer.style.display = "none";
  }
}

// Function to navigate to a path and handle URL change for Twixtor
function navigateToTwixtor(path) {
  window.history.pushState({}, '', path);
  twixtorurlChange();
}

// Event listener for popstate event
window.addEventListener('popstate', () => {
  twixtorurlChange();
});


function handletutorialclick(productId) {
  const tutorial = Tutorialdata.find(x => x.id === productId);
  if (tutorial) {
    var h1 = document.createElement('h1');
    var img = document.createElement('img');
    var editingapps = document.createElement('p');
    var videop = document.createElement('p');
    var videolink = document.createElement('iframe');
    var tutorialstep = document.createElement('div');
    var productsteps = document.createElement('p');
    editingapps.innerHTML = "<b>" + 'Editing App :- ' + "</b>" + "<br>" + tutorial.app + "<br>";
    videolink.width = "560";
    videolink.height = "315";
    videolink.src = tutorial.video;
    videolink.frameBorder = "0";
    videolink.allowFullscreen = true;
    h1.textContent = tutorial.name;
    img.src = tutorial.image;

    productsteps.innerHTML = "<br>" + "<b>" + "Tutorial Process Step by Step" + "</b>";
    detailscontainer.appendChild(h1);
    detailscontainer.appendChild(img);
    detailscontainer.appendChild(editingapps);
    detailscontainer.appendChild(videop);
    detailscontainer.appendChild(videolink);
    if (tutorial.tutorial) {
      var tutorialsteps = tutorial.tutorial.split('\n');
      for (var i = 0; i < tutorialsteps.length; i++) {
        if (tutorialsteps[i].trim() !== "") {
          var p = document.createElement('p');
          p.textContent = tutorialsteps[i];
          tutorialstep.appendChild(p);
        }
      }
    }
    detailscontainer.appendChild(productsteps);
    detailscontainer.appendChild(tutorialstep);
  }
}

function tutorialurlchange() {
  const path = window.location.pathname;

  if (path.startsWith('/tutorial/')) {
    const productId = path.substring('/tutorial/'.length);
    handletutorialclick(productId);
    productcontainer.style.display = "none";
    detailscontainer.style.display = "block";
  } else {
    detailscontainer.innerHTML = '';
    productcontainer.style.display = "grid";
    detailscontainer.style.display = "none";
  }
}

function navigateTotutorial(path) {
  window.history.pushState({}, '', path);
  tutorialurlchange();
}

window.addEventListener('popstate', tutorialurlchange);

// The rest of your existing code...




tutorialurlchange();
preseturlchange();
twixtorurlChange();
