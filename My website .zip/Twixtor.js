export const Twixtordata = [
  {
    id: 'page2-spy-x-family-season2-opning-ending-twixtor-clips',
    name: 'Spy x family Session 2 Opening adn ending Twixtor clips',
    image: '/Twixtor image/Spy x family opening and ending twixtor.jpg',
    date: 'date :2-October-2022',
    video: 'https://www.youtube.com/embed/Z5UYJqKfWTE',
    clips1: 'https://gplinks.co/FwejuYi',
    clips2: '',
    discrimination: 'If you use my Twixtor clips than you give me just credit ',

    },

  {
    id: 'page2-blue-lock-ep1-twixtor-clips',
    name: 'Blue lock episode 1 Twixtor clips',
    image: '/Twixtor image/Blue lock ep1.jpg',
    date: 'date :9-October-2022',
    video: 'https://www.youtube.com/embed/WqEJt48R0uU',
    clips1: 'https://gplinks.co/lFyj8aI4',
    clips2: '',

    discrimination: 'If you use my Twixtor clips than you give me just credit ',

    },

  {
    id: 'page2-chainsaw-man-makima-twixtor-clips',
    name: 'Chainsaw Man Makima Twixtor clips',
    image: '/Twixtor image/Makima.jpg',
    date: 'date :19-October-2022',
    video: 'https://www.youtube.com/embed/IPhRUb2QdK8',
    clips1: 'https://gplinks.co/ODRVmm',
    clips2: '',

    discrimination: 'If you use my Twixtor clips than you give me just credit ',

    },

  {
    id: 'page2-demon-slayer-nezuko-twixtor-clips',
    name: ' Demon slayer Nezuko Twixtor clips',
    image: '/Twixtor image/nezuko.jpg',
    date: 'date :19-December-2022',
    video: 'https://www.youtube.com/embed/MDSjuSO1fDE',
    clips1: 'https://gplinks.co/ODRVmm',
    clips2: '',

    discrimination: 'If you use my Twixtor clips than you give me just credit ',

    },

  {
    id: 'page2-the-angel-next-door-spoils-me-rotten-twixtor-clips',
    name: 'The angel next door spoils me rottenTwixtor clips',
    image: '/Twixtor image/The engel next door spoil ne rootean.jpg',
    date: 'date :23-Junuary-2023',
    video: 'https://www.youtube.com/embed/xJKZodfkX5I',
    clips1: 'https://gplinks.co/8bEplQ0',
    clips2: 'https://gplinks.co/WfNCp',

    discrimination: 'If you use my Twixtor clips than you give me just credit ',

    },

  {
    id: 'page2-one-piece-episode-1050-twixtor-clips',
    name: 'One ne piece episode 1050 Twixtor clips',
    image: '/Twixtor image/one piece episode 1050.jpg',
    date: 'date :25-Junuary-2023',
    video: 'https://www.youtube.com/embed/WkuhzNbNI_M',
    clips1: 'https://gplinks.co/uoZYq9',
    clips2: '',

    discrimination: 'If you use my Twixtor clips than you give me just credit ',

    },

  {
    id: 'page2-one-piece-episode-1051-twixtor-clips',
    name: 'One piece episode 1051 Twixtor clips',
    image: '/Twixtor image/One piece episode 1051.jpg',
    date: 'date :5-February-2023',
    video: 'https://www.youtube.com/embed/E9MVYRDTPWc',
    clips1: 'https://gplinks.co/RwNFUjsG',
    clips2: '',

    discrimination: 'If you use my Twixtor clips than you give me just credit ',

    },

  {
    id: 'page2-one-piece-episode-1052-twixtor-clips',
    name: 'One piece episode 1052 Twixtor clips',
    image: '/Twixtor image/one piece episode 1052.jpg',
    date: 'date :19-February-2023',
    video: 'https://www.youtube.com/embed/cfwqsC5elWA',
    clips1: 'https://gplinks.co/j3xHk',
    clips2: '',

    discrimination: 'If you use my Twixtor clips than you give me just credit ',

    },

  {
    id: 'page2-atack-on-titan-Season4-part3-trailer-twixtor-clips',
    name: 'Atack on Titan season 4 part 3 trailer Twixtor clips',
    image: '/Twixtor image/Aot1.jpg',
    date: 'date :25-February-2023',
    video: 'https://www.youtube.com/embed/xhQu4Okke3I',
    clips1: 'https://gplinks.co/0aBO',
    clips2: 'https://gplinks.co/o3CbEVmS',
    discrimination: 'If you use my Twixtor clips than you give me just credit ',
    },

  {
    id: 'page2-one-piece-episode-1053-twixtor-clips',
    name: 'One piece episode 1053 Twixtor clips',
    image: '/Twixtor image/one piece episode 1053.jpg',
    date: 'date :26-February-2023',
    video: 'https://www.youtube.com/embed/h2S3w77V7tc',
    clips1: 'https://gplinks.co/gX9Y',
    clips2: 'https://gplinks.co/vrpS0L',
    discrimination: 'If you use my Twixtor clips than you give me just credit ',
    },

  {
    id: 'page2-demon-slayer-season3-trailer-twixtor-clips',
    name: 'Demon slayer season 3 trailer Twixtor clips',
    image: '/Twixtor image/Dmoen slayer s3 trailer.jpg',
    date: 'date :2-March-2023',
    video: 'https://www.youtube.com/embed/nVr25gkuoyU',
    clips1: 'https://gplinks.co/wAZuq',
    clips2: '',
    discrimination: 'If you use my Twixtor clips than you give me just credit ',
    },

  {
    id: 'page2-atack-on titan-season-3-part-3-twixtor-clips',
    name: 'Atack on Titab season 3 part 3 Twixtor clips',
    image: '/Twixtor image/Atack on titatan season 3 part 3 .jpg',
    date: 'date :5-March-2023',
    video: 'https://www.youtube.com/embed/Wz2RzXg9ahk',
    clips1: 'https://gplinks.co/VhrLgPi',
    clips2: '',
    discrimination: 'If you use my Twixtor clips than you give me just credit ',
    },

  {
    id: 'page2-Boruto-episode-291-twixtor-clips',
    name: 'Boruto episode 291 Twixtor clips',
    image: '/Twixtor image/Boruto episode 291 .jpg',
    date: 'date :13-March-2023',
    video: 'https://www.youtube.com/embed/xuCA9ZiyUOU',
    clips1: 'https://gplinks.co/jyeUmo9L',
    clips2: 'https://gplinks.co/TBrRdJ',
    discrimination: 'If you use my Twixtor clips than you give me just credit ',
    },

  {
    id: 'page2-one-piece-red-uta-dance-twixtor-clips',
    name: 'one piece red uta Twixtor clips',
    image: '/Twixtor image/one piece red uta dance.jpg',
    date: 'date :18-March-2023',
    video: 'https://www.youtube.com/embed/MMAIWTr70bk',
    clips1: 'https://gplinks.co/PP8K',
    clips2: 'https://gplinks.co/Pl2Q4',
    discrimination: 'If you use my Twixtor clips than you give me just credit ',
    },

  {
    id: 'page2-one-piece-red-twixtor-clips',
    name: 'One piece red Twixtor clips',
    image: '/Twixtor image/one piece red .jpg',
    date: 'date :23-March-2023',
    video: 'https://www.youtube.com/embed/TKpfWBd6Y-8',
    clips1: 'https://gplinks.co/elei9',
    clips2: 'https://gplinks.co/jIpgkbL',
    discrimination: 'If you use my Twixtor clips than you give me just credit ',
    },

  {
    id: 'page2-solo-leveling-trailer-twixtor-clips',
    name: 'Solo leveling trailer Twixtor clips',
    image: '/Twixtor image/solo leveling trailer.jpg',
    date: 'date :21-March-2023',
    video: 'https://www.youtube.com/embed/CKQsoTCuvxg',
    clips1: 'https://gplinks.co/Awvp',
    clips2: 'https://gplinks.co/mAJ55',
    discrimination: 'If you use my Twixtor clips than you give me just credit ',
    },

  {
    id: 'page2-jujutsu-kaisen-s3 trailer-twixtor-clips',
    name: 'Jujutsu Kaisen Season 3 Trailer Twixtor clips',
    image: '/Twixtor image/jujutsu kaisen  s3 trailer.jpg',
    date: 'date :25-March-2023',
    video: 'https://www.youtube.com/embed/G55p3XU00RA',
    clips1: 'https://gplinks.co/BEO6',
    clips2: 'https://gplinks.co/8AR1',
    discrimination: 'If you use my Twixtor clips than you give me just credit ',
    },

  {
    id: 'page2-hell-paradise-twixtor-clips',
    name: 'Hell ParadiseTwixtor clips',
    image: '/Twixtor image/Hell paradise.jpg',
    date: 'date :3-April-2023',
    video: 'https://www.youtube.com/embed/uNYfAlXeVwk',
    clips1: 'https://gplinks.co/GWYKhG',
    clips2: 'https://gplinks.co/dQbxaMLH',
    discrimination: 'If you use my Twixtor clips than you give me just credit ',
    },

  {
    id: 'page2-kaguya-sama-love-is-war-first-kiss-never-ends-opening-twixtor-clips',
    name: 'Kaguya sama love is war first kiss never ends openingTwixtor clips',
    image: '/Twixtor image/kaguya sama love is war first kiss never ends opening.jpg',
    date: 'date :6-April-2023',
    video: 'https://www.youtube.com/embed/QUFdoYZ1iHU',
    clips1: 'https://gplinks.co/MOQBP4OP',
    clips2: 'https://gplinks.co/MK77l0',
    discrimination: 'If you use my Twixtor clips than you give me just credit ',
    },

  {
    id: 'page2-hell-paradise-episode-2-twixtor-clips',
    name: 'Hell Paradise Twixtor clips',
    image: '/Twixtor image/Hell Paradise ep 2.jpg',
    date: 'date :10-April-2023',
    video: 'https://www.youtube.com/embed/vt_B8IxzTfw',
    clips1: 'https://gplinks.co/s9LMafmn',
    clips2: 'https://gplinks.co/eJbaLB',
    discrimination: 'If you use my Twixtor clips than you give me just credit ',
    },

  {
    id: 'page2-demon-slayer-swordsmit-village-arc-opening-twixtor-clips',
    name: 'Demon slayer swordsmit village arc  openingTwixtor clips',
    image: '/Twixtor image/demon slayer swordsmit village arc opening.jpg',
    date: 'date :13-April-2023',
    video: 'https://www.youtube.com/embed/cdd9huO40rY',
    clips1: 'https://gplinks.co/0QplFj',
    clips2: 'https://gplinks.co/pb1yY6',
    discrimination: 'If you use my Twixtor clips than you give me just credit ',
    },

  {
    id: 'page2-demon-slayer-muichiro-twixtor-clips',
    name: 'Demon Slayer Muichiro Twixtor clips',
    image: '/Twixtor image/demon slayer2.jpg',
    date: 'date :17-April-2023',
    video: 'https://www.youtube.com/embed/iijI6guWcsY',
    clips1: 'https://gplinks.co/AUJkzgKr',
    clips2: 'https://gplinks.co/e4ylMt',
    discrimination: 'If you use my Twixtor clips than you give me just credit ',
    },

  {
    id: 'page2-demon-slayer-season-4-episode-2-twixtor-clips',
    name: 'Demon slayer season 4 episode 2 Twixtor clips',
    image: '/Twixtor image/demon slayer S4 ep2 .jpg',
    date: 'date :17-April-2023',
    video: 'https://www.youtube.com/embed/MF6ROmYocpU',
    clips1: 'https://gplinks.co/N4NfO',
    clips2: 'https://gplinks.co/lRpn8',
    discrimination: 'If you use my Twixtor clips than you give me just credit ',
    },

  {
    id: 'page2-oshi-no-ko-opening-twixtor-clips',
    name: 'Oshi no ko openingTwixtor clips',
    image: '/Twixtor image/oshi no ko .jpeg',
    date: 'date :21-April-2023',
    video: 'https://www.youtube.com/embed/NF37yb1J4kM',
    clips1: 'https://gplinks.co/Gi7ORQu',
    clips2: 'https://gplinks.co/hI0bM',
    discrimination: 'If you use my Twixtor clips than you give me just credit ',
    },

  {
    id: 'page2-oshi-no-ko-arima-kana-twixtor-clips',
    name: 'Oshi no ko Arima Kana Twixtor clips',
    image: '/Twixtor image/Arima kana.jpeg',
    date: 'date :27-April-2023',
    video: 'https://www.youtube.com/embed/kDxR0mLr3sI',
    clips1: 'https://gplinks.co/JjNQkzL',
    clips2: 'https://gplinks.co/FyZO',
    discrimination: 'If you use my Twixtor clips than you give me just credit ',
    },

  {
    id: 'page2-sanji-vs-queen-twixtor-clips',
    name: 'Sanji vs Queen Twixtor clips',
    image: '/Twixtor image/Sanji vs queen.jpg',
    date: 'date :7-May-2023',
    video: 'https://www.youtube.com/embed/XWKTxpXy9ag',
    clips1: 'https://gplinks.co/lf6Zu',
    clips2: '',
    discrimination: 'If you use my Twixtor clips than you give me just credit ',
    },

  {
    id: 'page2-my-Love-Story-with-Yamada-kun-at-Lv999-twixtor-clips',
    name: 'My Love Story with Yamada-kun at Lv999 Twixtor clips',
    image: '/Twixtor image/My Love Story with Yamada-kun at Lv999.jpg',
    date: 'date :20-May-2023',
    video: 'https://www.youtube.com/embed/NQPTGhX1SEs',
    clips1: 'https://gplinks.co/4wLb9',
    clips2: 'https://gplinks.co/VWyFR',
    discrimination: 'If you use my Twixtor clips than you give me just credit ',
    },

  {
    id: 'page2-zoro-vs-king-twixtor-clips',
    name: 'Zoro vs king Twixtor clips',
    image: '/Twixtor image/zoro vs king.jpg',
    date: 'date :21-May-2023',
    video: 'https://www.youtube.com/embed/ie--VsKjHM0',
    clips1: 'https://gplinks.co/Eqznw',
    clips2: '',
    discrimination: 'If you use my Twixtor clips than you give me just credit ',
    },

  {
    id: 'page2-Jujutsu-kaisen-season-2-trailer-twixtor-clips',
    name: 'Jujutsu kaisen season 2 trailer Twixtor clips',
    image: '/Twixtor image/jujutsu kaisen s2 trailer.jpg',
    date: 'date :21-May-2023',
    video: 'https://www.youtube.com/embed/O8IllfGOSbk',
    clips1: 'https://gplinks.co/BEO6',
    clips2: '',
    discrimination: 'If you use my Twixtor clips than you give me just credit ',
    },

  {
    id: 'page2-Oshi-no-ko-ruby-hasino-twixtor-clips',
    name: 'Oshi no ko Ruby Hoshino Twixtor clips',
    image: '/Twixtor image/Ruby.jpg',
    date: 'date :22-June-2023',
    video: 'https://www.youtube.com/embed/tLwhOmSlDVM',
    clips1: 'https://gplinks.co/mOHrdm',
    clips2: '',
    discrimination: 'If you use my Twixtor clips than you give me just credit ',
    },

  {
    id: 'page2-my-love-story-with-yamada-kun-at-lv999-twixtor-clips',
    name: 'My Love Story with Yamada-kun at Lv999 Twixtor clips',
    image: '/Twixtor image/My Love Story with Yamada-kun at Lv9995.jpg',
    date: 'date :28-June-2023',
    video: 'https://www.youtube.com/embed/J1Z0CPZRbwY',
    clips1: 'https://gplinks.co/MoRS71Pz',
    clips2: '',
    discrimination: 'If you use my Twixtor clips than you give me just credit ',
    },

  {
    id: 'page2-oshi-no-ko-episode-11-twixtor-clips',
    name: 'Oshi no ko Episode 11 Twixtor clips',
    image: '/Twixtor image/Oshi no ko Ep 11.jpg',
    date: 'date :29-June-2023',
    video: 'https://www.youtube.com/embed/LG0IAHI-0xo',
    clips1: 'https://gplinks.co/4ftP',
    clips2: 'https://gplinks.co/nkss7c',
    discrimination: 'If you use my Twixtor clips than you give me just credit ',
    },

  {
    id: 'page2-the-girl-i-like-forget-her-glasses-twixtor-clips',
    name: 'The girl I like forget her glassesTwixtor clips',
    image: '/Twixtor image/The girl I like forget her glasses.jpg',
    date: 'date :6-July-2023',
    video: 'https://www.youtube.com/embed/8EZzVi27wjs',
    clips1: 'https://gplinks.co/cBFEstk',
    clips2: 'https://gplinks.co/cGaJVoA',
    discrimination: 'If you use my Twixtor clips than you give me just credit ',
    },

  {
    id: 'page2-suzume-no-tojimari-twixtor-clips',
    name: 'Suzume no Tojimari Twixtor clips',
    image: '/Twixtor image/Suzume no Tojimari.jpg',
    date: 'date :8-July-2023',
    video: 'https://www.youtube.com/embed/nVmA5vYBSDk',
    clips1: 'https://gplinks.co/IX8nKhl',
    clips2: '',
    discrimination: 'If you use my Twixtor clips than you give me just credit ',
    },
  {
    id: 'page2-luffy-gear-5-twixtor-clips',
    name: 'Luffy Gear 5 Twixtor clips',
    image: '/Twixtor image/luffy Gear 5 Trailer twixtor.jpg',
    date: 'date :22-July-2023',
    video: 'https://www.youtube.com/embed/5IuS7MHVcDE',
    clips1: 'https://gplinks.co/7eSHbF',
    clips2: 'https://gplinks.co/QVUvq0',
    discrimination: 'If you use my Twixtor clips than you give me just credit ',
    },

]

